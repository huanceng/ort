package edu.harvard.hul.ois.jhove.module.pdf;

/** Pseudo-objects are entities returned by the parser that don't
 *  corresond to objects, such as dictionary and array enders. */
public abstract class PdfPseudoObject extends PdfObject {



}
